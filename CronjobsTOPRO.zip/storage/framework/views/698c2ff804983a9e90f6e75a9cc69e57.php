<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Notification Settings <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center gap-4">
            <a href="<?php echo e(route('settings')); ?>" class="p-2 text-midnight-400 hover:text-midnight-100 hover:bg-midnight-800 rounded-lg transition-colors">
                <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                </svg>
            </a>
            <div>
                <h1 class="text-2xl font-bold text-midnight-50">Notification Settings</h1>
                <p class="text-sm text-midnight-400 mt-1">Configure how you receive alerts</p>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="max-w-2xl">
        <form action="<?php echo e(route('settings.notifications.update')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="card p-6 space-y-6">
                <!-- Email Notifications -->
                <div>
                    <h3 class="text-lg font-semibold text-midnight-50 mb-4">Email Notifications</h3>
                    
                    <div class="space-y-4">
                        <div>
                            <label for="notification_email" class="label">Notification Email</label>
                            <input type="email" name="notification_email" id="notification_email" 
                                   value="<?php echo e(old('notification_email', $user->notification_email)); ?>" 
                                   class="input <?php $__errorArgs = ['notification_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> input-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   placeholder="<?php echo e($user->email); ?>">
                            <p class="mt-1.5 text-xs text-midnight-500">Leave empty to use your account email (<?php echo e($user->email); ?>)</p>
                            <?php $__errorArgs = ['notification_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1.5 text-sm text-red-400"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <!-- Alert Types -->
                <div class="pt-6 border-t border-midnight-800">
                    <h3 class="text-lg font-semibold text-midnight-50 mb-4">Alert Types</h3>
                    
                    <div class="space-y-4">
                        <div class="flex items-center justify-between p-4 bg-midnight-800/50 rounded-lg">
                            <div>
                                <p class="font-medium text-midnight-100">Job Failure Alerts</p>
                                <p class="text-sm text-midnight-400">Get notified when a job fails multiple times</p>
                            </div>
                            <div class="text-emerald-400">
                                <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                                </svg>
                            </div>
                        </div>

                        <div class="flex items-center justify-between p-4 bg-midnight-800/50 rounded-lg opacity-50">
                            <div>
                                <p class="font-medium text-midnight-100">Weekly Summary</p>
                                <p class="text-sm text-midnight-400">Receive a weekly report of all job activities</p>
                            </div>
                            <span class="badge-neutral text-xs">Coming Soon</span>
                        </div>

                        <div class="flex items-center justify-between p-4 bg-midnight-800/50 rounded-lg opacity-50">
                            <div>
                                <p class="font-medium text-midnight-100">Slack Notifications</p>
                                <p class="text-sm text-midnight-400">Send alerts to your Slack workspace</p>
                            </div>
                            <span class="badge-neutral text-xs">Coming Soon</span>
                        </div>
                    </div>
                </div>

                <div class="pt-4 border-t border-midnight-800">
                    <button type="submit" class="btn-primary">
                        <svg class="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                        </svg>
                        Save Changes
                    </button>
                </div>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>



<?php /**PATH C:\wamp64\www\CronjobsTOPRO\resources\views/settings/notifications.blade.php ENDPATH**/ ?>