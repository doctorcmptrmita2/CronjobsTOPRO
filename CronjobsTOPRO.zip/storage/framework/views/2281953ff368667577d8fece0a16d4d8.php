<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center gap-4">
            <a href="<?php echo e(route('jobs.show', $job)); ?>" class="p-2 text-midnight-400 hover:text-midnight-100 hover:bg-midnight-800 rounded-lg transition-colors">
                <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                </svg>
            </a>
            <div>
                <h1 class="text-2xl font-bold text-midnight-50">Run Details</h1>
                <p class="text-sm text-midnight-400 mt-1"><?php echo e($job->name); ?> • <?php echo e($run->ran_at->format('M d, Y H:i:s')); ?></p>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Main Info -->
        <div class="lg:col-span-2 space-y-6">
            <!-- Status Card -->
            <div class="card p-6">
                <div class="flex items-center justify-between mb-6">
                    <h3 class="text-lg font-semibold text-midnight-50">Execution Result</h3>
                    <?php if($run->success): ?>
                    <span class="badge-success text-sm px-4 py-1">
                        <svg class="w-4 h-4 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                        </svg>
                        Success
                    </span>
                    <?php else: ?>
                    <span class="badge-danger text-sm px-4 py-1">
                        <svg class="w-4 h-4 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                        </svg>
                        Failed
                    </span>
                    <?php endif; ?>
                </div>

                <dl class="grid grid-cols-2 md:grid-cols-4 gap-6">
                    <div>
                        <dt class="text-sm text-midnight-500 mb-1">Status Code</dt>
                        <dd class="text-2xl font-mono font-bold <?php echo e($run->status_code >= 200 && $run->status_code < 300 ? 'text-emerald-400' : 'text-red-400'); ?>">
                            <?php echo e($run->status_code ?? '—'); ?>

                        </dd>
                    </div>
                    <div>
                        <dt class="text-sm text-midnight-500 mb-1">Duration</dt>
                        <dd class="text-2xl font-mono font-bold text-midnight-100">
                            <?php echo e($run->duration_ms ? $run->duration_ms . 'ms' : '—'); ?>

                        </dd>
                    </div>
                    <div>
                        <dt class="text-sm text-midnight-500 mb-1">Ran At</dt>
                        <dd class="text-midnight-100">
                            <?php echo e($run->ran_at->format('M d, Y')); ?><br>
                            <span class="text-sm text-midnight-400"><?php echo e($run->ran_at->format('H:i:s')); ?></span>
                        </dd>
                    </div>
                    <div>
                        <dt class="text-sm text-midnight-500 mb-1">Method</dt>
                        <dd class="text-midnight-100 font-mono"><?php echo e($job->http_method); ?></dd>
                    </div>
                </dl>
            </div>

            <!-- Error Message -->
            <?php if($run->error_message): ?>
            <div class="card p-6 border-red-500/20">
                <h3 class="text-lg font-semibold text-red-400 mb-4 flex items-center gap-2">
                    <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                    </svg>
                    Error Message
                </h3>
                <pre class="bg-midnight-950 rounded-lg p-4 text-sm text-red-400 font-mono whitespace-pre-wrap overflow-x-auto"><?php echo e($run->error_message); ?></pre>
            </div>
            <?php endif; ?>

            <!-- Response Snippet -->
            <?php if($run->response_snippet): ?>
            <div class="card p-6">
                <h3 class="text-lg font-semibold text-midnight-50 mb-4">Response Body</h3>
                <pre class="bg-midnight-950 rounded-lg p-4 text-sm text-midnight-300 font-mono whitespace-pre-wrap overflow-x-auto max-h-96"><?php echo e($run->response_snippet); ?></pre>
            </div>
            <?php endif; ?>
        </div>

        <!-- Sidebar -->
        <div class="space-y-6">
            <!-- Job Info -->
            <div class="card p-6">
                <h3 class="text-lg font-semibold text-midnight-50 mb-4">Job Information</h3>
                <dl class="space-y-4">
                    <div>
                        <dt class="text-sm text-midnight-500">Name</dt>
                        <dd class="text-midnight-100 font-medium"><?php echo e($job->name); ?></dd>
                    </div>
                    <div>
                        <dt class="text-sm text-midnight-500">URL</dt>
                        <dd class="text-midnight-300 font-mono text-sm break-all"><?php echo e($job->url); ?></dd>
                    </div>
                    <div>
                        <dt class="text-sm text-midnight-500">Schedule</dt>
                        <dd class="text-midnight-100"><?php echo e($job->schedule_summary); ?></dd>
                    </div>
                    <div>
                        <dt class="text-sm text-midnight-500">Expected Status</dt>
                        <dd class="text-midnight-100 font-mono"><?php echo e($job->expected_status_from); ?> - <?php echo e($job->expected_status_to); ?></dd>
                    </div>
                </dl>
                
                <div class="mt-6 pt-6 border-t border-midnight-800">
                    <a href="<?php echo e(route('jobs.show', $job)); ?>" class="btn-secondary w-full justify-center text-sm">
                        View Job Details
                    </a>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\CronjobsTOPRO\resources\views/jobs/runs/show.blade.php ENDPATH**/ ?>