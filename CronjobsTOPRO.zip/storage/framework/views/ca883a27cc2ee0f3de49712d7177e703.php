<div class="space-y-6">
    <!-- Basic Info -->
    <div class="card p-6">
        <h3 class="text-lg font-semibold text-midnight-50 mb-6">Basic Information</h3>
        
        <div class="space-y-5">
            <div>
                <label for="name" class="label">Page Name <span class="text-red-400">*</span></label>
                <input type="text" name="name" id="name" value="<?php echo e(old('name', $statusPage->name ?? '')); ?>" 
                       class="input <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> input-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                       placeholder="My Service Status" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1.5 text-sm text-red-400"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div>
                <label for="slug" class="label">URL Slug <span class="text-red-400">*</span></label>
                <div class="flex items-center gap-2">
                    <span class="text-sm text-midnight-500"><?php echo e(url('/status/')); ?>/</span>
                    <input type="text" name="slug" id="slug" value="<?php echo e(old('slug', $statusPage->slug ?? '')); ?>" 
                           class="input flex-1 font-mono <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> input-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           placeholder="my-service" required>
                </div>
                <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1.5 text-sm text-red-400"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div>
                <label for="description" class="label">Description</label>
                <textarea name="description" id="description" rows="2" 
                          class="input" placeholder="Brief description of your service"><?php echo e(old('description', $statusPage->description ?? '')); ?></textarea>
            </div>

            <div class="flex items-center justify-between p-4 bg-midnight-800/50 rounded-lg border border-midnight-700">
                <div>
                    <p class="font-medium text-midnight-100">Make Public</p>
                    <p class="text-sm text-midnight-400">Allow anyone to view this status page</p>
                </div>
                <label class="relative inline-flex items-center cursor-pointer">
                    <input type="hidden" name="is_public" value="0">
                    <input type="checkbox" name="is_public" value="1" 
                           <?php echo e(old('is_public', $statusPage->is_public ?? false) ? 'checked' : ''); ?>

                           class="sr-only peer">
                    <div class="w-11 h-6 bg-midnight-700 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-accent-500/50 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-midnight-400 after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-accent-500 peer-checked:after:bg-white"></div>
                </label>
            </div>
        </div>
    </div>

    <!-- Select Jobs -->
    <div class="card p-6">
        <h3 class="text-lg font-semibold text-midnight-50 mb-6">Select Jobs to Monitor</h3>
        
        <?php if($jobs->isEmpty()): ?>
        <div class="text-center py-8">
            <p class="text-midnight-500">No active jobs found. Create some jobs first.</p>
        </div>
        <?php else: ?>
        <div class="space-y-2">
            <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <label class="flex items-center gap-3 p-3 bg-midnight-800/30 rounded-lg cursor-pointer hover:bg-midnight-800/50 transition-colors">
                <input type="checkbox" name="jobs[]" value="<?php echo e($job->id); ?>" 
                       <?php echo e(in_array($job->id, old('jobs', $selectedJobs ?? [])) ? 'checked' : ''); ?>

                       class="w-4 h-4 rounded border-midnight-700 bg-midnight-800 text-accent-500 focus:ring-accent-500 focus:ring-offset-midnight-900">
                <div class="flex-1">
                    <p class="text-sm font-medium text-midnight-200"><?php echo e($job->name); ?></p>
                    <p class="text-xs text-midnight-500 font-mono"><?php echo e($job->url); ?></p>
                </div>
                <?php if($job->is_active): ?>
                <span class="badge-success text-xs">Active</span>
                <?php endif; ?>
            </label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
    </div>

    <!-- Actions -->
    <div class="flex items-center justify-end gap-3">
        <a href="<?php echo e(route('status-pages.index')); ?>" class="btn-secondary">Cancel</a>
        <button type="submit" class="btn-primary">
            <svg class="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
            </svg>
            <?php echo e($statusPage->exists ? 'Update Status Page' : 'Create Status Page'); ?>

        </button>
    </div>
</div>




<?php /**PATH C:\wamp64\www\CronjobsTOPRO\resources\views/status-pages/_form.blade.php ENDPATH**/ ?>