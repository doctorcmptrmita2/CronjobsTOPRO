<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h1 class="text-2xl font-bold text-midnight-50">Admin Dashboard</h1>
        <p class="text-sm text-midnight-400 mt-1">System overview and metrics</p>
     <?php $__env->endSlot(); ?>

    <!-- Stats Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
        <div class="stat-card">
            <p class="stat-card-label">Total Users</p>
            <p class="stat-card-value"><?php echo e(number_format($stats['totalUsers'])); ?></p>
        </div>
        <div class="stat-card">
            <p class="stat-card-label">Total Jobs</p>
            <p class="stat-card-value"><?php echo e(number_format($stats['totalJobs'])); ?></p>
        </div>
        <div class="stat-card">
            <p class="stat-card-label">Active Jobs</p>
            <p class="stat-card-value text-emerald-400"><?php echo e(number_format($stats['activeJobs'])); ?></p>
        </div>
        <div class="stat-card">
            <p class="stat-card-label">Runs (24h)</p>
            <p class="stat-card-value"><?php echo e(number_format($stats['runsLast24h'])); ?></p>
        </div>
        <div class="stat-card">
            <p class="stat-card-label">Failures (24h)</p>
            <p class="stat-card-value text-red-400"><?php echo e(number_format($stats['failedRunsLast24h'])); ?></p>
        </div>
    </div>

    <!-- Top Failing Jobs -->
    <div class="card">
        <div class="px-6 py-4 border-b border-midnight-800">
            <h2 class="text-lg font-semibold text-midnight-50">Top Failing Jobs (24h)</h2>
        </div>
        
        <?php if($topFailing->isEmpty()): ?>
        <div class="px-6 py-12 text-center">
            <div class="w-16 h-16 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg class="w-8 h-8 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
            </div>
            <p class="text-midnight-400">No failures in the last 24 hours. Great job! 🎉</p>
        </div>
        <?php else: ?>
        <div class="overflow-x-auto">
            <table class="table">
                <thead>
                    <tr>
                        <th>Job</th>
                        <th>User</th>
                        <th>Failures</th>
                        <th>Last Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $topFailing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="font-medium text-midnight-100"><?php echo e($job->name); ?></td>
                        <td class="text-midnight-400"><?php echo e($job->user->email); ?></td>
                        <td>
                            <span class="badge-danger"><?php echo e($job->failures_count); ?> failures</span>
                        </td>
                        <td class="font-mono text-red-400"><?php echo e($job->last_status_code ?? '—'); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\CronjobsTOPRO\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>