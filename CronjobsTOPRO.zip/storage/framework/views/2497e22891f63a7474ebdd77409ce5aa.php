<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h1 class="text-2xl font-bold text-midnight-50">Users</h1>
        <p class="text-sm text-midnight-400 mt-1">Manage all registered users</p>
     <?php $__env->endSlot(); ?>

    <div class="card">
        <div class="overflow-x-auto">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Plan</th>
                        <th>Jobs</th>
                        <th>Joined</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-midnight-500 font-mono text-sm"><?php echo e($user->id); ?></td>
                        <td>
                            <div class="flex items-center gap-3">
                                <div class="w-8 h-8 bg-midnight-700 rounded-full flex items-center justify-center text-xs font-medium text-midnight-300">
                                    <?php echo e(strtoupper(substr($user->name, 0, 2))); ?>

                                </div>
                                <span class="font-medium text-midnight-100"><?php echo e($user->name); ?></span>
                                <?php if($user->is_admin): ?>
                                <span class="badge-warning text-xs">Admin</span>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td class="text-midnight-400"><?php echo e($user->email); ?></td>
                        <td>
                            <span class="badge-neutral"><?php echo e($user->plan?->name ?? 'Free'); ?></span>
                        </td>
                        <td class="text-midnight-400"><?php echo e($user->jobs_count); ?></td>
                        <td class="text-midnight-500 text-sm"><?php echo e($user->created_at->format('M d, Y')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        
        <?php if($users->hasPages()): ?>
        <div class="px-6 py-4 border-t border-midnight-800">
            <?php echo e($users->links()); ?>

        </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\CronjobsTOPRO\resources\views/admin/users/index.blade.php ENDPATH**/ ?>